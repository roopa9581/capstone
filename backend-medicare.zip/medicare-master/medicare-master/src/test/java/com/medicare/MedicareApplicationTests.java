package com.medicare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicareApplicationTests {

	@Test
	void contextLoads() {
	}

}
